# management-system
Hello!
this is a school management system using the laravel project. I will add many functionality as i can including the basic CRUD system.

Thnaks All
Binoy Sarker
Bangldesh
