<?php $__env->startSection('title'); ?>
  
  WpF Degree : Admission Result
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  
  <!--=========== BEGIN COURSE BANNER SECTION ================-->
  <section id="imgBanner">
    <h2>Admission Result</h2>
  </section>
  <!--=========== END COURSE BANNER SECTION ================-->
  
  <?php echo $__env->make('partials.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
  <!--=========== BEGIN CONTACT SECTION ================-->
  <section id="contact">
    <div class="container">
     
     <div class="row">
       <div class="col-lg-8 col-md-8 col-sm-8">
        
         <table class="table table-hover wow fadeInLeft">
           <caption>Individual Student result</caption>
           <span><a href="<?php echo e(url('/ms/add-student-result')); ?>" class="btn btn-primary">Add Admission Result</a></span>
           <thead>
             <tr>
               <th>Name</th>
               <th>Class</th>
               <th>Roll</th>
               <th>Result</th>
               <th>Action</th>
             </tr>
           </thead>
           <tbody>
            <?php if($results->isEmpty()): ?>
              <?php echo e("No data is in the array"); ?>

            <?php else: ?>
              
             <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
               <tr>
                 <td><a href="<?php echo e(url('/ms/show-student-profile/'.$result->id)); ?>"><?php echo e($result->student_name); ?> <i class="fa fa-eye"></i></a></td>
                 <td><?php echo e($result->student_class); ?></td>
                 <td><?php echo e($result->student_roll); ?></td>
                 <td><?php echo e($result->student_result); ?></td>
                 <td>
                   <a href="<?php echo e(url('/ms/edit-student-result')); ?><?php echo e('/'.$result->id); ?> " class="btn btn-warning" title="">Edit</a>
                   <a href="<?php echo e(url('/ms/delete-student-result')); ?><?php echo e('/'.$result->id); ?> " class="btn btn-danger" title="">Delete</a>
                 </td>
               </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
           </tbody>
         </table>
       </div>
       <div class="col-lg-4 col-md-4 col-sm-4">
         <div class="contact_address wow fadeInRight">
           
           <div class="single_sidebar">
             <h2>Quick Links <span class="fa fa-angle-double-right"></span></h2>
             <ul>
               <li><a href="#">Admission Notice'17</a></li>
               <li><a href="#">Application Instructions</a></li>
               <li><a href="#">Catchment Area Insturction</a></li>
             </ul>
           </div>
           <div class="address_group">
            <ul class="footer_social">
              <li><a href="#" class="soc_tooltip" title="" data-placement="top" data-toggle="tooltip" data-original-title="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#" class="soc_tooltip" title="" data-placement="top" data-toggle="tooltip" data-original-title="Twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#" class="soc_tooltip" title="" data-placement="top" data-toggle="tooltip" data-original-title="Google+"><i class="fa fa-google-plus"></i></a></li>
              <li><a href="#" class="soc_tooltip" title="" data-placement="top" data-toggle="tooltip" data-original-title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="#" class="soc_tooltip" title="" data-placement="top" data-toggle="tooltip" data-original-title="Youtube"><i class="fa fa-youtube"></i></a></li>
              </ul>
           </div>
         </div>
       </div>
     </div>
    </div>
  </section>
  <!--=========== END CONTACT SECTION ================-->

  
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>