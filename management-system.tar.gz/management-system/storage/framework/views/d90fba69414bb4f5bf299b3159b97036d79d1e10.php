
  <?php if(session()->has('message')): ?>

    <center><h2 class="title_two singlecourse_price wow fadeInRight"><?php echo e($msg = session()->get('message')); ?></h2></center>
	
  <?php endif; ?>
